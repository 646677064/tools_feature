#ifndef FEATURE_EXTRACTOR_MOVIDIUS_HPP
#define FEATURE_EXTRACTOR_MOVIDIUS_HPP

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "fp16.h"
#include <mvnc.h>

using namespace std;
typedef unsigned short half;

namespace tunicornface
{
typedef struct _ssd_output
{
  int class_id;
  float score;
  float x1;
  float y1;
  float x2;
  float y2;
};


class FeatureExtractorMovidius
{
public:
  FeatureExtractorMovidius()
  {
  }
  ~FeatureExtractorMovidius();

   
  int LoadModel(const std::string &graph_filename);
  void SetDevice(int gpu_id);

  half * PreProcess(const cv::Mat &inputImg);
  

  int Predict(const cv::Mat &inputImg, vector<_ssd_output> &output_ssd,float threhold=0.6);
  int Predict(const cv::Mat &inputImg, vector<float> &out);
  int PredictFp16(unsigned short* input, int w, int h, int c, vector<float> &feat);
 
  void SetTargetHeight(int target_height);
  void SetTargetWidth(int target_width);
  void SetTargetBlobName(string target_blob_name);
  long ComputeCosinSimilarity(const std::vector<float> &x, const std::vector<float> &y, float &similarity);

private:
  mvncStatus retCode;
  void *deviceHandle = NULL;
  void *graphHandle = NULL;
  void *graphFileBuf = NULL;
  char devName[100];
  int m_target_height = 224;
  int m_target_width = 224;
  string m_target_blob_name = "softmax_output";
  cv::Mat m_ImageCopy;
  float CalcVecProduct(const std::vector<float> &vec1, const std::vector<float> &vec2) const;
  float CalcVectorLen(const std::vector<float> &vec);
  void NormFeatures(std::vector<float> &feature);
  void *LoadFile(const char *path, unsigned int *length);

};

} // namespace tunicornface

#endif
