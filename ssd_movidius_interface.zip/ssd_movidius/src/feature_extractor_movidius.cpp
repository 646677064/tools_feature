#include "feature_extractor_movidius.hpp"
#include <string>
#include <vector>
#include <iostream>
#include <cmath>

namespace tunicornface
{

int FeatureExtractorMovidius::LoadModel(const std::string &graph_filename)
{
  retCode = mvncGetDeviceName(0, devName, 100);
  if (retCode != MVNC_OK)
  { // failed to get device name, maybe none plugged in.
    printf("No NCS devices found\n");
    return -1;
  }

  // Try to open the NCS device via the device name
  retCode = mvncOpenDevice(devName, &deviceHandle);
  if (retCode != MVNC_OK)
  { // failed to open the device.
    printf("Could not open NCS device\n");
    return -1;
  }

  // deviceHandle is ready to use now.
  // Pass it to other NC API calls as needed and close it when finished.
  printf("Successfully opened NCS device!\n");

  // Now read in a graph file
  unsigned int graphFileLen;
  graphFileBuf = LoadFile(graph_filename.c_str(), &graphFileLen);

  // allocate the graph

  retCode = mvncAllocateGraph(deviceHandle, &graphHandle, graphFileBuf, graphFileLen);
  if (retCode != MVNC_OK)
  { // error allocating graph
    printf("Could not allocate graph for file: %s\n", graph_filename.c_str());
    printf("Error from mvncAllocateGraph is: %d\n", retCode);
    return -1;
  }

  printf("Successfully allocated graph for %s\n", graph_filename.c_str());

  return 0;
}

// Load a graph file
// caller must free the buffer returned.
void *FeatureExtractorMovidius::LoadFile(const char *path, unsigned int *length)
{
  FILE *fp;
  char *buf;

  fp = fopen(path, "rb");
  if (fp == NULL)
    return 0;
  fseek(fp, 0, SEEK_END);
  *length = ftell(fp);
  rewind(fp);
  if (!(buf = (char *)malloc(*length)))
  {
    fclose(fp);
    return 0;
  }
  if (fread(buf, 1, *length, fp) != *length)
  {
    fclose(fp);
    free(buf);
    return 0;
  }
  fclose(fp);
  return buf;
}

FeatureExtractorMovidius::~FeatureExtractorMovidius()
{

  if (graphHandle != NULL)
  {
    retCode = mvncDeallocateGraph(graphHandle);
    graphHandle = NULL;
  }
  if (deviceHandle != NULL)
  {
    retCode = mvncCloseDevice(deviceHandle);
    deviceHandle = NULL;
  }
  if (graphFileBuf != NULL)
  {
    free(graphFileBuf);
  }
}

half *FeatureExtractorMovidius::PreProcess(const cv::Mat &img)
{

  cv::Mat sample_resized;
  if (img.rows != m_target_height || img.cols != m_target_width)
  {
    cv::resize(img, sample_resized, cv::Size(m_target_width, m_target_height));
  }
  else
  {
    sample_resized = img;
  }

  cv::Mat sample_float;
  sample_resized.convertTo(sample_float, CV_32F);
  cv::Mat sample_normalized;
  // sample_normalized = (sample_float - 127.5) * 0.0078125;
  //sample_normalized = (sample_float - 127.5) / 128.0;
  cv::Mat mean_;
  int num_channels_ = 3;//sample_float.channels();
      std::vector<cv::Mat> channels;
    float values[]={104.0,117.0,123.0};
    for (int i = 0; i < min(num_channels_,int(sizeof(values)/sizeof(values[0]))); ++i) 
    {
      /* Extract an individual channel. */
      cv::Mat channel(sample_float.rows, sample_float.cols, CV_32FC1,
          cv::Scalar(values[i]));
      channels.push_back(channel);
    }
    cv::merge(channels, mean_);
  cv::subtract(sample_float, mean_, sample_normalized);

  float *imgfp32;
  half *imgfp16;
  imgfp16 = (half *)malloc(sizeof(*imgfp16) * m_target_height * m_target_width * 3);
  imgfp32 = (float *)malloc(sizeof(*imgfp32) * m_target_height * m_target_width * 3);

  int m = 0;
  for (int i = 0; i < m_target_height; i++)
  {
    for (int j = 0; j < m_target_width; j++)
    {
      imgfp32[3 * m + 0] = sample_normalized.at<cv::Vec3f>(i, j).val[0]; // R
      imgfp32[3 * m + 1] = sample_normalized.at<cv::Vec3f>(i, j).val[1]; // G
      imgfp32[3 * m + 2] = sample_normalized.at<cv::Vec3f>(i, j).val[2]; // B
      m += 1;
    }
  }
  cout << "Float Image pixel(RGB):" << endl;
  m = 0;
  for (int i = 0; i < 5; i++)
  {
    for (int j = 0; j < 5; j++)
    {

      printf("(%f,%f,%f)", imgfp32[3 * m + 0], imgfp32[3 * m + 1], imgfp32[3 * m + 2]);
      m += 1;
    }
    cout << endl;
  }

  floattofp16((unsigned char *)imgfp16, imgfp32, 3 * m_target_height * m_target_width);

  cout << "Half Image pixel:" << endl;
  m = 0;
  for (int i = 0; i < 5; i++)
  {
    for (int j = 0; j < 5; j++)
    {
      printf("(%hu,%hu,%hu)", imgfp16[3 * m + 0], imgfp16[3 * m + 1], imgfp16[3 * m + 2]);
      m += 1;
    }
    cout << endl;
  }
  free(imgfp32);
  return imgfp16;
}

int FeatureExtractorMovidius::PredictFp16(unsigned short* input, int w, int h, int c, vector<float> &feat){
  return 0;
}

int FeatureExtractorMovidius::Predict(const cv::Mat &inputImg, vector<_ssd_output> &output_ssd,float threhold)
{
  // vector<float> out;
  if (inputImg.empty())
    return -1;

  half *imageBufFp16 = PreProcess(inputImg);
  unsigned int lenBufFp16 = 3 * m_target_height * m_target_height * sizeof(*imageBufFp16);

  // start the inference with mvncLoadTensor()
  retCode = mvncLoadTensor(graphHandle, imageBufFp16, lenBufFp16, NULL);
  float *resultData32 = NULL;
  void *resultData16 = NULL;
  if (retCode != MVNC_OK)
  { // error loading tensor
    printf("Could not load tensor\n");
    printf("Error from mvncLoadTensor is: %d\n", retCode);
  }
  else
  { // the inference has been started, now call mvncGetResult() for the
    // inference result
    void *userParam;
    unsigned int lenResultData;
    retCode = mvncGetResult(graphHandle, &resultData16, &lenResultData, &userParam);
    if (retCode == MVNC_OK)
    { // Successfully got the result.  The inference result is in the buffer pointed to by resultData
      // printf("Successfully got the inference result for image \n");
      // printf("resultData is %d bytes which is %d 16-bit floats.\n", lenResultData, lenResultData / (int)sizeof(half));

      // convert half precision floats to full floats
      int numResults = lenResultData / sizeof(half);

      resultData32 = (float *)malloc(numResults * sizeof(*resultData32));
      if (resultData32)
      {
        fp16tofloat(resultData32, (unsigned char *)resultData16, numResults);
        // for (int index = 0; index < numResults; index++)
        // {
        //   out.push_back(resultData32[index]);
        // }
        int num_valid_boxes = resultData32[0];
        printf("caffe num_valid_boxes : %d resultData32 len : %d",num_valid_boxes,numResults);
        const int ssd_stride = 7;
        //std::vector<_ssd_output> output_ssd;
        for (int i = 0; i < numResults; i=i+7)
        {
            int base_index = 7+ i * 7;

            _ssd_output ss_soutput;
            ss_soutput.class_id = int(resultData32[base_index + 1]);
            ss_soutput.score = resultData32[base_index + 2];
            ss_soutput.x1 = max(0, int(resultData32[base_index + 3] * inputImg.cols));
            ss_soutput.y1 = max(0, int(resultData32[base_index + 4] * inputImg.rows));
            ss_soutput.x2 = min(inputImg.cols, int(resultData32[base_index + 5] * inputImg.cols));
            ss_soutput.y2 = min(inputImg.rows, int(resultData32[base_index + 6] * inputImg.rows));
            if (ss_soutput.score>threhold)
            {
              output_ssd.push_back(ss_soutput);
            }
        }
      }
    }
  }
  // int i;
  // for (i= 0; i < 10/*numResults*/; i++)
  // {
  //   printf("(%d) %f, ", i, out[i]);
  // }
  // printf("\n");

  // NormFeatures(out);

  // for (i= 0; i < 10/*numResults*/; i++)
  // {
  //   printf("(%d) %f, ", i, out[i]);
  // }
  printf("\n");

  if (resultData32 != NULL)
  {
    free(resultData32);
  }

  if (resultData16 != NULL)
  {
    // free(resultData16);
  }

  if (imageBufFp16 != NULL)
  {
    free(imageBufFp16);
  }
  return 0;
}

int FeatureExtractorMovidius::Predict(const cv::Mat &inputImg, vector<float> &out)
{
  // vector<float> out;
  if (inputImg.empty())
    return -1;

  half *imageBufFp16 = PreProcess(inputImg);
  unsigned int lenBufFp16 = 3 * m_target_height * m_target_height * sizeof(*imageBufFp16);

  // start the inference with mvncLoadTensor()
  retCode = mvncLoadTensor(graphHandle, imageBufFp16, lenBufFp16, NULL);
  float *resultData32 = NULL;
  void *resultData16 = NULL;
  if (retCode != MVNC_OK)
  { // error loading tensor
    printf("Could not load tensor\n");
    printf("Error from mvncLoadTensor is: %d\n", retCode);
  }
  else
  { // the inference has been started, now call mvncGetResult() for the
    // inference result
    void *userParam;
    unsigned int lenResultData;
    retCode = mvncGetResult(graphHandle, &resultData16, &lenResultData, &userParam);
    if (retCode == MVNC_OK)
    { // Successfully got the result.  The inference result is in the buffer pointed to by resultData
      // printf("Successfully got the inference result for image \n");
      // printf("resultData is %d bytes which is %d 16-bit floats.\n", lenResultData, lenResultData / (int)sizeof(half));

      // convert half precision floats to full floats
      int numResults = lenResultData / sizeof(half);

      resultData32 = (float *)malloc(numResults * sizeof(*resultData32));
      if (resultData32)
      {
        fp16tofloat(resultData32, (unsigned char *)resultData16, numResults);
        // for (int index = 0; index < numResults; index++)
        // {
        //   out.push_back(resultData32[index]);
        // }
        int num_valid_boxes = resultData32[0];
        const int ssd_stride = 7;
        std::vector<_ssd_output> output_ssd;
        for (int i = 0; i < num_valid_boxes; ++i)
        {
            int base_index = 7+ i * 7;

            _ssd_output ss_soutput;
            ss_soutput.class_id = int(resultData32[base_index + 1]);
            ss_soutput.score = resultData32[base_index + 2];
            ss_soutput.x1 = max(int(0.0), int(resultData32[base_index + 3] * inputImg.cols));
            ss_soutput.y1 = max(int(0.0), int(resultData32[base_index + 4] * inputImg.rows));
            ss_soutput.x2 = min(inputImg.cols, int(resultData32[base_index + 5] * inputImg.cols));
            ss_soutput.y2 = min(inputImg.rows, int(resultData32[base_index + 6] * inputImg.rows));
            if (ss_soutput.score>0.6)
            {
              output_ssd.push_back(ss_soutput);
            }
        }
      }
    }
  }
  // int i;
  // for (i= 0; i < 10/*numResults*/; i++)
  // {
  //   printf("(%d) %f, ", i, out[i]);
  // }
  // printf("\n");

  // NormFeatures(out);

  // for (i= 0; i < 10/*numResults*/; i++)
  // {
  //   printf("(%d) %f, ", i, out[i]);
  // }
  printf("\n");

  if (resultData32 != NULL)
  {
    free(resultData32);
  }

  if (resultData16 != NULL)
  {
    // free(resultData16);
  }

  if (imageBufFp16 != NULL)
  {
    free(imageBufFp16);
  }
  return 0;
}

void FeatureExtractorMovidius::SetTargetHeight(int target_height)
{
  m_target_height = target_height;
}
void FeatureExtractorMovidius::SetTargetWidth(int target_width)
{
  m_target_width = target_width;
}
void FeatureExtractorMovidius::SetTargetBlobName(string target_blob_name)
{
  m_target_blob_name = target_blob_name;
}

float FeatureExtractorMovidius::CalcVectorLen(const std::vector<float> &vec)
{
  float sum = 0.0;
  int size = vec.size();
  for (int i = 0; i < size; i++)
  {
    sum += (vec[i] * vec[i]);
  }

  return std::sqrt(sum);
}

void FeatureExtractorMovidius::NormFeatures(std::vector<float> &feature)
{
  float sum = 0.0f;
  for (int i = 0; i < feature.size(); i++)
  {
    sum += (feature[i] * feature[i]);
  }
  float len = std::max(std::sqrt(sum), 0.0001f);

  for (int j = 0; j < feature.size(); j++)
  {
    feature[j] /= len;
  }
}

long FeatureExtractorMovidius::ComputeCosinSimilarity(const std::vector<float> &x, const std::vector<float> &y, float &similarity)
{

  /*
       float norm1 = CalcVectorLen(x);

    // assert(norm1>0);
    float norm2 = CalcVectorLen(y);

    // assert(norm2>0);
    float product = CalcVecProduct(x, y);
    float cosine_similarity = product/(norm1*norm2);
    */
  // suppose the feature vector is normalized
  float product = CalcVecProduct(x, y);
  float cosine_similarity = product;
  float cosine_similarity_norm = (cosine_similarity + 1) / 2;
  similarity = cosine_similarity_norm;

  // similarity = 1 / (1 + std::exp((-cosine_similarity_norm + 0.6) * 12));
  if (similarity > 1)
    similarity = 1.f;
  if (similarity < 0)
    similarity = 0.f;

  return 0;
}

float FeatureExtractorMovidius::CalcVecProduct(const std::vector<float> &vec1, const std::vector<float> &vec2) const
{
  int size1 = vec1.size();
  int size2 = vec2.size();
  // assert(size1 == size2);
  if (size1 != size2)
  {
    return 0.0;
  }

  float sum = 0.0;
  for (int i = 0; i < size1; i++)
  {
    sum += (vec1[i] * vec2[i]);
  }

  return sum;
}
} // namespace tunicornface
