#include "feature_extractor.hpp"
#include <string>
#include <vector>
#include <iostream>
#include <cmath>

using namespace caffe;

namespace tunicornface
{

void FeatureExtractor::LoadModel(const std::string &prototxt, const std::string &caffemodel)
{
  m_pNet = std::shared_ptr<caffe::Net<float> >(new caffe::Net<float>(prototxt,caffe::TEST));
  m_pNet->CopyTrainedLayersFrom(caffemodel);
}

void FeatureExtractor::LoadModel(const vector<caffe::NetParameter> &params)
{
  m_pNet.reset(new caffe::Net<float>(params[0]));
  m_pNet->CopyTrainedLayersFrom(params[1]);
}
void FeatureExtractor::SetDevice(int device_id)
{
  /*
  if (device_id >= 0 && caffe::GPUAvailable())
  {
    caffe::SetMode(caffe::GPU, device_id);
  }
  else
  {
    caffe::SetMode(caffe::CPU, -1);
  }
  */
 caffe::Caffe::set_mode(caffe::Caffe::CPU);

}

void FeatureExtractor::LoadModel(const std::string &model_filename)
{
  std::vector<caffe::NetParameter> params;
  // caffe::loadMultipleMessagesFromBinaryFile(model_filename, params);
  LoadModel(params);
}

void FeatureExtractor::PreProcess(const cv::Mat &img, std::vector<cv::Mat> *input_channels)
{
  /*
       cv::Mat resizedImg(m_target_height, m_target_width, CV_32FC3);
       cv::Mat Temp;
       cv::Mat Temp2(m_target_height, m_target_width, CV_8UC3);
       if(img.rows > img.cols)
       {
       int k = m_target_height*img.rows/img.cols;
       cv::resize(img,Temp,cv::Size(m_target_width, k),cv::INTER_LINEAR);
       Temp2 = Temp(cv::Rect(0, (k-224-1)/2, 224,224));
       }
       else
       {
       int k = m_target_width*img.cols/img.rows;
       cv::resize(img,Temp,cv::Size(k, m_target_height),cv::INTER_LINEAR);
       Temp2 = Temp(cv::Rect((k-224-1)/2, 0, 224,224));
       }
       Temp2.convertTo(resizedImg, CV_32FC1, 1/255.0);
       resizedImg = (resizedImg - cv::Scalar(0.406, 0.456, 0.485))/0.225;

       cv::Mat resizedImg2(m_target_height, m_target_width, CV_32FC3);
       cv::cvtColor(resizedImg, resizedImg2, cv::COLOR_BGR2RGB);

       cv::split(resizedImg2, *input_channels);
       return resizedImg;
       */

  cv::Mat sample_resized;
  if (img.rows != m_target_height || img.cols != m_target_width)
  {
    cv::resize(img, sample_resized, cv::Size(m_target_width, m_target_height));
  }
  else
  {
    sample_resized = img;
  }

  cv::Mat sample_float;
  sample_resized.convertTo(sample_float, CV_32F);
  cv::Mat sample_normalized;
  //sample_normalized = (sample_float - 127.5) / 128.0;
  cv::Mat mean_;
  int num_channels_ = 3;//sample_float.channels();
      std::vector<cv::Mat> channels;
    float values[]={104.0,117.0,123.0};
    for (int i = 0; i < min(num_channels_,int(sizeof(values)/sizeof(values[0]))); ++i) 
    {
      /* Extract an individual channel. */
      cv::Mat channel(sample_float.rows, sample_float.cols, CV_32FC1,
          cv::Scalar(values[i]));
      channels.push_back(channel);
    }
    cv::merge(channels, mean_);
  cv::subtract(sample_float, mean_, sample_normalized);
  cv::split(sample_normalized, *input_channels);
}

void FeatureExtractor::PreprocessBatch(const std::vector<cv::Mat> &imgs, std::vector<std::vector<cv::Mat>> *input_batch_channels)
{
  for (int i = 0; i < imgs.size(); i++)
  {
    std::vector<cv::Mat> *input_channels = &(input_batch_channels->at(i));
    /*
         cv::Mat resizedImg(m_target_height, m_target_width, CV_32FC3);
         cv::Mat Temp;
         cv::Mat Temp2(m_target_height, m_target_width, CV_8UC3);
         if(imgs[i].rows > imgs[i].cols)
         {
         int k = m_target_height*imgs[i].rows/imgs[i].cols;
         cv::resize(imgs[i],Temp,cv::Size(m_target_width, k),cv::INTER_LINEAR);
         Temp2 = Temp(cv::Rect(0, (k-224-1)/2, 224,224));
         }
         else
         {
         int k = m_target_width*imgs[i].cols/imgs[i].rows;
         cv::resize(imgs[i],Temp,cv::Size(k, m_target_height),cv::INTER_LINEAR);
         Temp2 = Temp(cv::Rect((k-224-1)/2, 0, 224,224));
         }
         Temp2.convertTo(resizedImg, CV_32FC1, 1/255.0);
         resizedImg = (resizedImg - cv::Scalar(0.406, 0.456, 0.485))/0.225;

         cv::Mat resizedImg2(m_target_height, m_target_width, CV_32FC3);
         cv::cvtColor(resizedImg, resizedImg2, cv::COLOR_BGR2RGB);

         cv::split(resizedImg2, *input_channels);
         */
    cv::Mat img = imgs[i];
    cv::Mat sample_resized;
    if (img.rows != m_target_height || img.cols != m_target_width)
    {
      cv::resize(img, sample_resized, cv::Size(m_target_width, m_target_height));
    }
    else
    {
      sample_resized = img;
    }

    cv::Mat sample_float;
    sample_resized.convertTo(sample_float, CV_32F);
    cv::Mat sample_normalized;
    sample_normalized = (sample_float - 127.5) / 128.0;
    cv::split(sample_normalized, *input_channels);
  }
}

void FeatureExtractor::WrapInputLayer(std::vector<cv::Mat> *input_channels)
{
  auto input_layer = m_pNet->blob_by_name("data");

  int width = input_layer->width();
  int height = input_layer->height();
  float *input_data = input_layer->mutable_cpu_data();
  for (int i = 0; i < input_layer->channels(); ++i)
  {
    cv::Mat channel(height, width, CV_32FC1, input_data);
    input_channels->push_back(channel);
    input_data += width * height;
  }
}

void FeatureExtractor::WrapBatchInputLayer(std::vector<std::vector<cv::Mat>> *input_batch_channels)
{
  auto input_layer = m_pNet->blob_by_name("data");

  int width = input_layer->width();
  int height = input_layer->height();
  int num = input_layer->num();
  float *input_data = input_layer->mutable_cpu_data();
  for (int i = 0; i < num; i++)
  {
    std::vector<cv::Mat> input_channels;
    for (int j = 0; j < input_layer->channels(); j++)
    {
      cv::Mat channel(height, width, CV_32FC1, input_data);
      input_channels.push_back(channel);
      input_data += width * height;
    }
    input_batch_channels->push_back(input_channels);
  }
}

int FeatureExtractor::Predict(const cv::Mat &inputImg, vector<_ssd_output> &output_ssd,float threhold)
{
  // vector<float> out;
  if (inputImg.empty())
    return -1;
  // vector<string> layers = {m_target_blob_name};
  // m_pNet->MarkOutputs(layers);

  auto input_layer = m_pNet->blob_by_name("data");
  input_layer->Reshape(1, 3, m_target_height, m_target_width);
  std::vector<cv::Mat> input_channels;
  WrapInputLayer(&input_channels);

  m_ImageCopy = inputImg.clone();
  PreProcess(m_ImageCopy, &input_channels);
  m_pNet->Forward();

  // auto output_layer = m_pNet->blob_by_name(m_target_blob_name);

  // std::vector<int> shape = output_layer->shape();
  // int feat_len = 1;
  // for (int i = 1; i < shape.size(); i++)
  // {
  //   feat_len *= shape[i];
  // }
  // // int feat_len = 512; //shape[1] * shape[2] * shape[3];
  // auto begin1 = output_layer->cpu_data();
  // auto end1 = feat_len + begin1;
  // // std::vector<float> out(begin1, end1);
  // out = std::vector<float>(begin1, end1);

  // NormFeatures(out);
  /* Copy the output layer to a std::vector */
  Blob<float>* result_blob = m_pNet->output_blobs()[0];
  const float* result = result_blob->cpu_data();
  const int num_det = result_blob->height();
  // vector<vector<float> > detections;
  // for (int k = 0; k < num_det; ++k) {
  //   if (result[0] == -1) {
  //     // Skip invalid detection.
  //     result += 7;
  //     continue;
  //   }
  //   vector<float> detection(result, result + 7);
  //   detections.push_back(detection);
  //   result += 7;
  // }
        int num_valid_boxes = result[0];
        printf("caffe num_valid_boxes : %d num_det: %d",num_valid_boxes,num_det);

        const int ssd_stride = 7;
        //std::vector<_ssd_output> output_ssd;
        for (int i = 0; i < num_det; i=i+7)
        {
            int base_index = 7+ i * 7;

            _ssd_output ss_soutput;
            ss_soutput.class_id = int(result[base_index + 1]);
            ss_soutput.score = result[base_index + 2];
            ss_soutput.x1 = max(int(0.0), int(result[base_index + 3] * inputImg.cols));
            ss_soutput.y1 = max(int(0.0), int(result[base_index + 4] * inputImg.rows));
            ss_soutput.x2 = min(inputImg.cols, int(result[base_index + 5] * inputImg.cols));
            ss_soutput.y2 = min(inputImg.rows, int(result[base_index + 6] * inputImg.rows));
            if (ss_soutput.score>threhold)
            {
              output_ssd.push_back(ss_soutput);
            }
        }

  return 0;
}

std::vector<std::vector<float>> FeatureExtractor::BatchPredict(const std::vector<cv::Mat *> &ptr_imgs)
{

  vector<cv::Mat> imgs;
  for (size_t i = 0; i < ptr_imgs.size(); i++)
  {
    imgs.push_back(*ptr_imgs[i]);
  }

  return BatchPredict(imgs);
}

std::vector<std::vector<float>> FeatureExtractor::BatchPredict(const std::vector<cv::Mat> &imgs)
{
  std::vector<std::vector<float>> temp_vec;
  if (imgs.size() == 0)
    return temp_vec;

  // vector<string> layers = {m_target_blob_name};
  // m_pNet->MarkOutputs(layers);

  auto input_layer = m_pNet->blob_by_name("data");
  int batch_size = imgs.size();
  int num_channels = 3;
  input_layer->Reshape(batch_size, num_channels, m_target_height, m_target_width);

  std::vector<std::vector<cv::Mat>> input_batch;
  WrapBatchInputLayer(&input_batch);
  PreprocessBatch(imgs, &input_batch);

  m_pNet->Forward();
  auto output_layer = m_pNet->blob_by_name(m_target_blob_name);

  std::vector<int> shape = output_layer->shape();
  int feat_len = 1;
  for (int i = 1; i < shape.size(); i++)
  {
    feat_len *= shape[i];
  }
  // int feat_len = shape[1] * shape[2] * shape[3];
  auto begin = output_layer->cpu_data();

  // std::vector<std::vector<float> > feats;
  for (int i = 0; i < batch_size; i++)
  {
    std::vector<float> out(begin + i * feat_len, begin + i * feat_len + feat_len);
    temp_vec.push_back(out);
  }

  for (int i = 0; i < batch_size; i++)
  {
    NormFeatures(temp_vec[i]);
  }

  return temp_vec;
}

void FeatureExtractor::SetTargetHeight(int target_height)
{
  m_target_height = target_height;
}
void FeatureExtractor::SetTargetWidth(int target_width)
{
  m_target_width = target_width;
}
void FeatureExtractor::SetTargetBlobName(string target_blob_name)
{
  m_target_blob_name = target_blob_name;
}

float FeatureExtractor::CalcVectorLen(const std::vector<float> &vec)
{
  float sum = 0.0;
  int size = vec.size();
  for (int i = 0; i < size; i++)
  {
    sum += (vec[i] * vec[i]);
  }

  return std::sqrt(sum);
}

void FeatureExtractor::NormFeatures(std::vector<float> &feature)
{
  float sum = 0.0f;
  for (int i = 0; i < feature.size(); i++)
  {
    sum += (feature[i] * feature[i]);
  }
  float len = std::max(std::sqrt(sum), 0.0001f);

  for (int j = 0; j < feature.size(); j++)
  {
    feature[j] /= len;
  }
}

long FeatureExtractor::ComputeCosinSimilarity(const std::vector<float> &x, const std::vector<float> &y, float &similarity)
{

  /*
       float norm1 = CalcVectorLen(x);

    // assert(norm1>0);
    float norm2 = CalcVectorLen(y);

    // assert(norm2>0);
    float product = CalcVecProduct(x, y);
    float cosine_similarity = product/(norm1*norm2);
    */
  // suppose the feature vector is normalized
  float product = CalcVecProduct(x, y);
  float cosine_similarity = product;
  float cosine_similarity_norm = (cosine_similarity + 1) / 2;
  similarity = cosine_similarity_norm;

  // similarity = 1 / (1 + std::exp((-cosine_similarity_norm + 0.6) * 12));
  if (similarity > 1)
    similarity = 1.f;
  if (similarity < 0)
    similarity = 0.f;

  return 0;
}

float FeatureExtractor::CalcVecProduct(const std::vector<float> &vec1, const std::vector<float> &vec2) const
{
  int size1 = vec1.size();
  int size2 = vec2.size();
  // assert(size1 == size2);
  if (size1 != size2)
  {
    return 0.0;
  }

  float sum = 0.0;
  for (int i = 0; i < size1; i++)
  {
    sum += (vec1[i] * vec2[i]);
  }

  return sum;
}
} // namespace tunicornface
