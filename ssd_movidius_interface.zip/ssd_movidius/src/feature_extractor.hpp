#ifndef FEATURE_EXTRACTOR_HPP
#define FEATURE_EXTRACTOR_HPP

#include <caffe/caffe.hpp>
#include <caffe/proto/caffe.pb.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "feature_extractor_movidius.hpp"

using namespace std;

namespace tunicornface
{

class FeatureExtractor
{
public:
  FeatureExtractor()
  {
  }
  ~FeatureExtractor()
  {
  }

  void LoadModel(const std::string &prototxt, const std::string &caffemodel);
  void LoadModel(const vector<caffe::NetParameter> &params);
  void LoadModel(const std::string &model_filename);
  void SetDevice(int gpu_id);

  void PreProcess(const cv::Mat &inputImg, std::vector<cv::Mat> *input_channels);
  void PreprocessBatch(const std::vector<cv::Mat> &imgs, std::vector<std::vector<cv::Mat>> *input_batch_channels);
  void WrapInputLayer(std::vector<cv::Mat> *input_channels);
  void WrapBatchInputLayer(std::vector<std::vector<cv::Mat>> *input_batch_channels);

  int Predict(const cv::Mat &inputImg, vector<_ssd_output> &output_ssd,float threhold=0.6);
  std::vector<std::vector<float>> BatchPredict(const std::vector<cv::Mat> &imgs);
  std::vector<std::vector<float>> BatchPredict(const std::vector<cv::Mat *> &ptr_imgs);
  void SetTargetHeight(int target_height);
  void SetTargetWidth(int target_width);
  void SetTargetBlobName(string target_blob_name);
  long ComputeCosinSimilarity(const std::vector<float> &x, const std::vector<float> &y, float &similarity);

private:
  std::shared_ptr<caffe::Net<float>> m_pNet;
  int m_target_height = 224;
  int m_target_width = 224;
  string m_target_blob_name = "softmax_output";
  cv::Mat m_ImageCopy;
  float CalcVecProduct(const std::vector<float> &vec1, const std::vector<float> &vec2) const;
  float CalcVectorLen(const std::vector<float> &vec);
  void NormFeatures(std::vector<float> &feature);
};

} // namespace tunicornface

#endif
