// Copyright 2017 Intel Corporation.
// The source code, information and material ("Material") contained herein is
// owned by Intel Corporation or its suppliers or licensors, and title to such
// Material remains with Intel Corporation or its suppliers or licensors.
// The Material contains proprietary information of Intel or its suppliers and
// licensors. The Material is protected by worldwide copyright laws and treaty
// provisions.
// No part of the Material may be used, copied, reproduced, modified, published,
// uploaded, posted, transmitted, distributed or disclosed in any way without
// Intel's prior express written permission. No license under any patent,
// copyright or other intellectual property rights in the Material is granted to
// or conferred upon you, either expressly, by implication, inducement, estoppel
// or otherwise.
// Any license under such intellectual property rights must be express and
// approved by Intel in writing.

#include <stdio.h>
#include <stdlib.h>
#include "feature_extractor_movidius.hpp"
#include "feature_extractor.hpp"
#include <iostream>

using namespace std;
using namespace tunicornface;

struct Image {
  unsigned char* pixels;
  int w, h, c;
  unsigned short int *pixels_fp16;
  string filename;
};


void PrintVec(vector<float> &vec, int limit=10){
  int total = vec.size();
  limit = std::min(total, limit);
  for(int i = 0; i < limit; i++){
    cout<<"("<<i<<")"<<vec[i]<<" ";
  }
  cout<<endl;
}


int main(int argc, char **argv)
{
  string model_root = "/home/liushuai/ssd_interface/ncappzoo/caffe/SSD_squeezenet/";
  string deploy = model_root + "/" + "tunicorn_carplate_det_001_001.prototxt";
  string caffemodel= model_root + "/" + "tunicorn_carplate_det_001_001.caffemodel";
  string target_blob_name = "fc1";
  string far_tar_file_path = "../test/far_tar_mx_s4.txt";
  bool is_rgb = true;
  
  

  
  FeatureExtractor extractor;
  extractor.LoadModel(deploy, caffemodel);
  extractor.SetDevice(0);
  extractor.SetTargetHeight(300);
  extractor.SetTargetWidth(300);
  extractor.SetTargetBlobName(target_blob_name);


  string graph_filename = model_root + "/" + "graph";

  FeatureExtractorMovidius mv_extractor;
  mv_extractor.LoadModel(graph_filename);
  mv_extractor.SetTargetHeight(300);
  mv_extractor.SetTargetWidth(300);

  std::cout<<deploy<<std::endl;
  std::cout<<caffemodel<<std::endl;
  // std::cout<<far_tar_file_path<<std::endl;
  //string filename = "/home/liuxinhao/workspace/data/renzheng_test_2541/renzheng_test_169457/0.jpg";
  string filename = "/home/liushuai/ssd_interface/ncappzoo/caffe/SSD_squeezenet/1.jpg";
  cout<<filename<<endl;
  cv::Mat im = cv::imread(filename);
  cout<<im.rows<<"x"<<im.cols<<endl;

  if(is_rgb){
    cvtColor(im, im, CV_BGR2RGB);
  }

  vector<_ssd_output> feat;
  mv_extractor.Predict(im, feat,0.6);
  cout<<feat.size()<<endl;
  cout<<"NCSDK output:"<<endl;
    for (int i = 0; i < feat.size(); ++i) 
    {
        

           cv::rectangle( im, cvPoint(static_cast<int>(feat[i].x1), static_cast<int>(feat[i].y1)),     \
                                   cvPoint(static_cast<int>(feat[i].x2), static_cast<int>(feat[i].y2)),   \
                                   cvScalar(feat[i].class_id*1.6, feat[i].class_id*2.4,feat[i].x1*0.8 ), 3, 4, 0 );
    }
    cv::imwrite("NCSDK.jpg", im);
  //PrintVec(feat, 10);


  vector<_ssd_output> feat2;
  cv::Mat im1 = cv::imread(filename);
  extractor.Predict(im1, feat2,0.6);
  cout<<feat2.size()<<endl;
  cout<<"Caffe output:"<<endl;
    for (int i = 0; i < feat.size(); ++i) 
    {
        

           cv::rectangle( im1, cvPoint(static_cast<int>(feat[i].x1), static_cast<int>(feat[i].y1)),     \
                                   cvPoint(static_cast<int>(feat[i].x2), static_cast<int>(feat[i].y2)),   \
                                   cvScalar(feat[i].class_id*1.6, feat[i].class_id*2.4,feat[i].x1*0.8 ), 3, 4, 0 );
    }
    cv::imwrite("caffe.jpg", im1);
  //PrintVec(feat2, 10);


  return 0;
}
